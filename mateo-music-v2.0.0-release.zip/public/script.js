const token=localStorage.getItem('token');
const api=async(url,opt={})=>{opt.headers={...(opt.headers||{}),...(token?{Authorization:`Bearer ${token}`}:{})};const r=await fetch(url,opt);const d=await r.json().catch(()=>({message:'Server error'}));if(!r.ok)throw new Error(d.message||'Request gagal');return d};
async function loadSongs(){const el=document.querySelector('.songs');if(!el)return;const songs=await api('/api/songs');el.innerHTML=songs.length?songs.map(s=>`<article class="card"><div class="cover" style="${s.cover?`background:url('/covers/${encodeURIComponent(s.cover)}') center/cover`:''}"></div><h3>${escapeHtml(s.title)}</h3><p>${escapeHtml(s.artist)}</p><audio controls preload="none" src="/music/${encodeURIComponent(s.file)}" style="width:100%"></audio></article>`).join(''):'<p class="muted">Belum ada lagu.</p>'}
function escapeHtml(v){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
loadSongs().catch(console.error);
