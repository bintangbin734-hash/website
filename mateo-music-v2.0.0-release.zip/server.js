const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const ROOT = __dirname;
const DATA = path.join(ROOT, 'data');
const MUSIC = path.join(ROOT, 'uploads', 'music');
const COVERS = path.join(ROOT, 'uploads', 'covers');
for (const dir of [DATA, MUSIC, COVERS]) fs.mkdirSync(dir, { recursive: true });
const usersFile = path.join(DATA, 'users.json');
const songsFile = path.join(DATA, 'songs.json');
if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');
if (!fs.existsSync(songsFile)) fs.writeFileSync(songsFile, '[]');

const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('JWT_SECRET must be set and at least 32 characters long. Copy .env.example to .env and configure it.');
  process.exit(1);
}

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api', rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));

app.use(express.static(path.join(ROOT, 'public'), { extensions: ['html'] }));
app.use('/music', express.static(MUSIC, { fallthrough: false }));
app.use('/covers', express.static(COVERS, { fallthrough: false }));

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return []; }
}
function writeJson(file, value) {
  const temp = `${file}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2), 'utf8');
  fs.renameSync(temp, file);
}
function publicUser(u) { return { id: u.id, username: u.username, role: u.role, createdAt: u.createdAt }; }
function safeName(name) { return path.basename(name).replace(/[^a-zA-Z0-9._-]/g, '_'); }
function sign(user) { return jwt.sign({ id: user.id, username: user.username, role: user.role }, JWT_SECRET, { expiresIn: '7d' }); }
function auth(req, res, next) {
  const token = req.cookies?.token || (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ success: false, message: 'Login diperlukan' });
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { return res.status(401).json({ success: false, message: 'Sesi tidak valid atau sudah berakhir' }); }
}
function admin(req, res, next) { if (req.user?.role !== 'admin') return res.status(403).json({ success: false, message: 'Akses admin diperlukan' }); next(); }
function validateCredentials(username, password) {
  return typeof username === 'string' && /^[a-zA-Z0-9_.-]{3,32}$/.test(username) && typeof password === 'string' && password.length >= 8 && password.length <= 128;
}

const musicStorage = multer.diskStorage({
  destination: MUSIC,
  filename: (req, file, cb) => cb(null, `${crypto.randomUUID()}-${safeName(file.originalname)}`)
});
const coverStorage = multer.diskStorage({
  destination: COVERS,
  filename: (req, file, cb) => cb(null, `${crypto.randomUUID()}-${safeName(file.originalname)}`)
});
const musicUpload = multer({ storage: musicStorage, limits: { fileSize: 25 * 1024 * 1024 }, fileFilter: (req, file, cb) => cb(null, ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/ogg'].includes(file.mimetype)) });
const coverUpload = multer({ storage: coverStorage, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => cb(null, ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)) });

app.post('/api/auth/register', async (req, res) => {
  const { username, password } = req.body || {};
  if (!validateCredentials(username, password)) return res.status(400).json({ success: false, message: 'Username 3-32 karakter (huruf/angka/._-) dan password 8-128 karakter.' });
  const users = readJson(usersFile);
  if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ success: false, message: 'Username sudah digunakan' });
  const user = { id: crypto.randomUUID(), username, password: await bcrypt.hash(password, 12), role: users.length === 0 ? 'admin' : 'user', createdAt: new Date().toISOString() };
  users.push(user); writeJson(usersFile, users);
  res.status(201).json({ success: true, message: 'Register berhasil', user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== 'string' || typeof password !== 'string') return res.status(400).json({ success: false, message: 'Username dan password wajib diisi' });
  const user = readJson(usersFile).find(u => u.username.toLowerCase() === username.toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ success: false, message: 'Username atau password salah' });
  res.json({ success: true, token: sign(user), user: publicUser(user) });
});

app.get('/api/auth/me', auth, (req, res) => res.json({ success: true, user: publicUser(req.user) }));
app.get('/api/songs', (req, res) => res.json(readJson(songsFile)));

app.post('/api/songs', auth, admin, musicUpload.single('music'), coverUpload.single('cover'), (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'File musik wajib diupload' });
  const { title, artist, album = '' } = req.body || {};
  if (!title?.trim() || !artist?.trim()) { fs.rmSync(req.file.path, { force: true }); if (req.files?.cover) fs.rmSync(req.files.cover.path, { force: true }); return res.status(400).json({ success: false, message: 'Judul dan artist wajib diisi' }); }
  const song = { id: crypto.randomUUID(), title: title.trim().slice(0, 150), artist: artist.trim().slice(0, 150), album: String(album).trim().slice(0, 150), file: req.file.filename, cover: req.files?.cover?.filename || null, uploadedAt: new Date().toISOString() };
  const songs = readJson(songsFile); songs.unshift(song); writeJson(songsFile, songs);
  res.status(201).json({ success: true, song });
});

app.delete('/api/songs/:id', auth, admin, (req, res) => {
  const songs = readJson(songsFile); const song = songs.find(s => s.id === req.params.id);
  if (!song) return res.status(404).json({ success: false, message: 'Lagu tidak ditemukan' });
  writeJson(songsFile, songs.filter(s => s.id !== req.params.id));
  if (song.file) fs.rmSync(path.join(MUSIC, path.basename(song.file)), { force: true });
  if (song.cover) fs.rmSync(path.join(COVERS, path.basename(song.cover)), { force: true });
  res.json({ success: true, message: 'Lagu dihapus' });
});

app.get('/api/admin/stats', auth, admin, (req, res) => res.json({ success: true, totalUsers: readJson(usersFile).length, totalSongs: readJson(songsFile).length }));

app.get('*', (req, res) => res.sendFile(path.join(ROOT, 'public', 'index.html')));
app.use((err, req, res, next) => { console.error(err); if (err instanceof multer.MulterError) return res.status(400).json({ success: false, message: `Upload error: ${err.message}` }); res.status(500).json({ success: false, message: 'Terjadi kesalahan server' }); });
app.listen(PORT, () => console.log(`Mateo Music v2.0.0 berjalan di port ${PORT}`));
