# Release 2.0.0

- Removed accidental `server.jsu` and `y` files.
- Removed bundled `node_modules`; dependencies are installed during deployment.
- Added production environment configuration.
- Added Helmet security headers and API rate limiting.
- Added JWT authentication and server-side admin authorization.
- Added random upload filenames and upload size/type limits.
- Added optional cover uploads.
- Added song deletion with file cleanup.
- Added admin statistics endpoint.
- Added responsive modern UI and real song catalog/audio playback.
- Added startup validation for JWT_SECRET.
- Added deployment documentation.
