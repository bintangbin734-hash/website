# Mateo Music v2.0.0

Modern self-hosted music streaming starter with public catalog, authentication, admin-only uploads and local JSON storage.

## Requirements
- Node.js 20+
- Linux or Windows server

## Production setup
1. Extract the release.
2. Run `npm install --omit=dev`.
3. Copy `.env.example` to `.env`.
4. Set `JWT_SECRET` to a random secret of at least 32 characters.
5. Run `npm start`.
6. Open port 3000 or set `PORT`.

The first registered account becomes `admin`. Later registrations are normal users.

## Upload limits
- Music: MP3/WAV/OGG, max 25 MB.
- Covers: JPG/PNG/WebP, max 5 MB.

## Resale note
Replace branding, author/license information, and demo media before redistribution. Only redistribute media/assets for which you have rights.
